
package service;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class AccountService {

    private static final String URL =
            "jdbc:mysql://localhost:3309/student_budget_tracker";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                URL, DB_USER, DB_PASSWORD);
    }

    public static boolean createAccount(
            String username, char[] password) throws IOException {

        String sql = "INSERT INTO users (username, password_hash) "
                   + "VALUES (?, ?)";

        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        byte[] hash = hashPassword(password, salt);

        String passwordHash =
                Base64.getEncoder().encodeToString(salt) + ":" +
                Base64.getEncoder().encodeToString(hash);

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username.trim());
            stmt.setString(2, passwordHash);

            stmt.executeUpdate();
            return true;

        } catch (SQLException ex) {

            // MySQL error 1062 means duplicate username.
            if (ex.getErrorCode() == 1062) {
                return false;
            }

            throw new IOException(
                    "Unable to create account. Check your database connection.",
                    ex);
        }
    }

    public static boolean login(
            String username, char[] password) throws IOException {

        String sql =
                "SELECT password_hash FROM users WHERE username = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username.trim());

            try (ResultSet rs = stmt.executeQuery()) {

                if (!rs.next()) {
                    return false;
                }

                String savedValue = rs.getString("password_hash");
                String[] parts = savedValue.split(":", 2);

                if (parts.length != 2) {
                    return false;
                }

                byte[] salt =
                        Base64.getDecoder().decode(parts[0]);

                byte[] expectedHash =
                        Base64.getDecoder().decode(parts[1]);

                byte[] actualHash = hashPassword(password, salt);

                return MessageDigest.isEqual(
                        expectedHash, actualHash);
            }

        } catch (SQLException ex) {
            throw new IOException(
                    "Unable to access account data. Check your database connection.",
                    ex);
        }
    }

    private static byte[] hashPassword(
            char[] password, byte[] salt) {

        PBEKeySpec spec = new PBEKeySpec(
                password, salt, 65536, 256);

        try {
            return SecretKeyFactory
                    .getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec)
                    .getEncoded();

        } catch (java.security.GeneralSecurityException ex) {
            throw new IllegalStateException(
                    "Unable to process password.", ex);

        } finally {
            spec.clearPassword();
        }
    }
}

