
package service;

import database.DBConnection;
import model.Expense;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

public class ExpenseService {

    private static final ExpenseService INSTANCE =
            new ExpenseService();

    private double monthlyBudget = 0.0;

    public static ExpenseService getInstance() {
        return INSTANCE;
    }

    // Add an expense to MySQL
    public void addExpense(Expense expense) {
        String sql = "INSERT INTO expenses "
                + "(description, category, amount, expense_date) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                throw new SQLException("Database connection failed.");
            }

            try (PreparedStatement ps = con.prepareStatement(
                    sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

                ps.setString(1, expense.getDescription());
                ps.setString(2, expense.getCategory());
                ps.setDouble(3, expense.getAmount());
                ps.setDate(4,
                        java.sql.Date.valueOf(expense.getDate()));

                ps.executeUpdate();

                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        expense.setId(keys.getInt(1));
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(
                    "Unable to save expense: " + e.getMessage(), e);
        }
    }

    // Retrieve expenses from MySQL
    public List<Expense> getExpenses() {
        List<Expense> expenses = new ArrayList<>();

        String sql = "SELECT id, description, category, amount, "
                + "expense_date FROM expenses ORDER BY id ASC";

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                throw new SQLException("Database connection failed.");
            }

            try (PreparedStatement ps = con.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    expenses.add(new Expense(
                            rs.getInt("id"),
                            rs.getString("description"),
                            rs.getString("category"),
                            rs.getDouble("amount"),
                            rs.getDate("expense_date").toLocalDate()
                    ));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(
                    "Unable to load expenses: " + e.getMessage(), e);
        }

        return expenses;
    }

    // Update an expense using its actual database ID
    public void updateExpense(int expenseId, Expense expense) {
        String sql = "UPDATE expenses SET description = ?, "
                + "category = ?, amount = ?, expense_date = ? "
                + "WHERE id = ?";

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                throw new SQLException("Database connection failed.");
            }

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, expense.getDescription());
                ps.setString(2, expense.getCategory());
                ps.setDouble(3, expense.getAmount());
                ps.setDate(4,
                        java.sql.Date.valueOf(expense.getDate()));
                ps.setInt(5, expenseId);

                int rows = ps.executeUpdate();

                if (rows == 0) {
                    throw new SQLException(
                            "No expense found with ID " + expenseId);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(
                    "Unable to update expense: " + e.getMessage(), e);
        }
    }

    // Delete an expense using its actual database ID
    public void deleteExpense(int expenseId) {
        String sql = "DELETE FROM expenses WHERE id = ?";

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                throw new SQLException("Database connection failed.");
            }

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, expenseId);

                int rows = ps.executeUpdate();

                if (rows == 0) {
                    throw new SQLException(
                            "No expense found with ID " + expenseId);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(
                    "Unable to delete expense: " + e.getMessage(), e);
        }
    }

    // Set monthly budget (currently stored in memory)
    public void setMonthlyBudget(double budget) {
        if (budget <= 0) {
            throw new IllegalArgumentException(
                    "Budget must be greater than zero.");
        }
        monthlyBudget = budget;
    }

    public double getMonthlyBudget() {
        return monthlyBudget;
    }

    public double getTotalExpenses() {
        double total = 0;

        for (Expense expense : getExpenses()) {
            total += expense.getAmount();
        }

        return total;
    }

    public double getExpensesThisMonth() {
        double total = 0;
        YearMonth currentMonth = YearMonth.now();

        for (Expense expense : getExpenses()) {
            if (YearMonth.from(expense.getDate())
                    .equals(currentMonth)) {
                total += expense.getAmount();
            }
        }

        return total;
    }

    public double getRemainingBudget() {
        return monthlyBudget - getExpensesThisMonth();
    }

    public int getTransactionCount() {
        return getExpenses().size();
    }

    public double getCategoryTotal(String category) {
        double total = 0;

        for (Expense expense : getExpenses()) {
            if (expense.getCategory() != null
                    && expense.getCategory()
                            .equalsIgnoreCase(category)
                    && YearMonth.from(expense.getDate())
                            .equals(YearMonth.now())) {
                total += expense.getAmount();
            }
        }

        return total;
    }
}