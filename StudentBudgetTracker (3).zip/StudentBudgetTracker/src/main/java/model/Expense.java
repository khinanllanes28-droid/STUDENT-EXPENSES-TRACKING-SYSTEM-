
package model;

import java.time.LocalDate;

public class Expense {

    private int id;
    private String description;
    private String category;
    private double amount;
    private LocalDate date;

    // Constructor for a new expense
    public Expense(String description, String category,
                   double amount, LocalDate date) {
        this(0, description, category, amount, date);
    }

    // Constructor for an expense retrieved from MySQL
    public Expense(int id, String description, String category,
                   double amount, LocalDate date) {
        this.id = id;
        this.description = description;
        this.category = category;
        this.amount = amount;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public String getCategory() {
        return category;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDate getDate() {
        return date;
    }
}
