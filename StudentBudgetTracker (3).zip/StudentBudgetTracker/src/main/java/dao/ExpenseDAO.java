

package dao;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

public class ExpenseDAO {

    public void addExpense(
            String description,
            String category,
            double amount,
            LocalDate date) throws SQLException {

        String sql = "INSERT INTO expenses "
                + "(description, category, amount, expense_date) "
                + "VALUES (?, ?, ?, ?)";

        Connection con = DBConnection.getConnection();

        if (con == null) {
            throw new SQLException("Database connection failed.");
        }

        try (con;
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, description);
            pst.setString(2, category);
            pst.setDouble(3, amount);
            pst.setDate(4, java.sql.Date.valueOf(date));

            pst.executeUpdate();
        }
    }
}

