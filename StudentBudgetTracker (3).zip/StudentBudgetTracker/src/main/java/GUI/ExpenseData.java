package GUI;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ExpenseData {

    public static class Expense {
        public String description;
        public String category;
        public double amount;
        public LocalDate date;

        public Expense(String description, String category,
                       double amount, LocalDate date) {
            this.description = description;
            this.category = category;
            this.amount = amount;
            this.date = date;
        }
    }

    public static final List<Expense> expenses = new ArrayList<>();

    public static void addExpense(String description,
                                  String category,
                                  double amount,
                                  LocalDate date) {
        expenses.add(new Expense(
            description, category, amount, date
        ));
    }
}