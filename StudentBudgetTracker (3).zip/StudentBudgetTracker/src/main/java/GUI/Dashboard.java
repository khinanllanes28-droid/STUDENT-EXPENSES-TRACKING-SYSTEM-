/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

import model.Expense;
import service.ExpenseService;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.JOptionPane;

/**
 *
 * @author Administrator
 */
public class Dashboard extends javax.swing.JFrame {
    private double monthlyBudget = 0.0;
      private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Dashboard.class.getName());
      private void refreshDashboard() {
            java.util.List<Expense> expenses =
            ExpenseService.getInstance().getExpenses();

    javax.swing.table.DefaultTableModel tableModel =
            (javax.swing.table.DefaultTableModel)
                    tblRecentExpenses.getModel();

    // Clear the old rows
    tableModel.setRowCount(0);
    double total = 0.0;
double highest = 0.0;
int transactions = expenses.size();

double budget = ExpenseService.getInstance().getMonthlyBudget();

double monthlyTotal =
        ExpenseService.getInstance().getExpensesThisMonth();

double remaining = Math.max(0.0, budget - monthlyTotal);

int remainingPercent = 0;

if (budget > 0) {
    remainingPercent = (int) Math.round(
            remaining / budget * 100
    );

    remainingPercent = Math.max(0, Math.min(100, remainingPercent));
}



LocalDate latestDate = null;

 double food = 0.0;
double transportation = 0.0;
double education = 0.0;
double bills = 0.0;
double others = 0.0;

for (Expense expense : expenses) {
    double amount = expense.getAmount();
    String category = expense.getCategory();

    total += amount;

    if (amount > highest) {
        highest = amount;
    }

   if (category != null) {
    category = category.trim();

    if (category.equalsIgnoreCase("Food")) {
        food += amount;
    } else if (category.equalsIgnoreCase("Transportation")) {
        transportation += amount;
    } else if (category.equalsIgnoreCase("Education")) {
        education += amount;
    } else if (category.equalsIgnoreCase("Bills")) {
        bills += amount;
    } else {
        others += amount;
    }
}

    if (expense.getDate() != null &&
        (latestDate == null ||
         expense.getDate().isAfter(latestDate))) {
        latestDate = expense.getDate();
    }
}


double maxCategory = Math.max(1.0,
        Math.max(food, Math.max(transportation,
        Math.max(education, Math.max(bills, others)))));

jProgressBar1.setMinimum(0);
jProgressBar1.setMaximum(100);
jProgressBar1.setValue(
        (int) Math.round(food / maxCategory * 100));

barTransportation.setMinimum(0);
barTransportation.setMaximum(100);
barTransportation.setValue(
        (int) Math.round(transportation / maxCategory * 100));

barEducation.setMinimum(0);
barEducation.setMaximum(100);
barEducation.setValue(
        (int) Math.round(education / maxCategory * 100));

barBills.setMinimum(0);
barBills.setMaximum(100);
barBills.setValue(
        (int) Math.round(bills / maxCategory * 100));

barOthers.setMinimum(0);
barOthers.setMaximum(100);
barOthers.setValue(
        (int) Math.round(others / maxCategory * 100));

    // Show the five most recent expenses
    int start = Math.max(0, expenses.size() - 5);

    for (int i = expenses.size() - 1; i >= start; i--) {

        Expense expense = expenses.get(i);

        tableModel.addRow(new Object[]{
            i + 1,
            expense.getDescription(),
            expense.getCategory(),
            String.format("₱%.2f", expense.getAmount()),
            expense.getDate()
        });
    }
    
      

    // Update dashboard summary cards
    lblTotalValue.setText(String.format("₱%.2f", total));

    tblTransactionsValue.setText(
            String.valueOf(transactions));

    lblHighestValue2.setText(
            String.format("₱%.2f", highest));

    lblLatestDate.setText(
            latestDate == null
                    ? "No transactions yet"
                    : latestDate.format(
                            DateTimeFormatter.ofPattern("MMMM dd, yyyy")
                    )
    );


    // Update the budget field
 
    // Update the budget field
    double savedBudget =
            ExpenseService.getInstance().getMonthlyBudget();

    if (savedBudget > 0) {
        monthlyBudget = savedBudget;
        txtBudget.setText(String.format("%.2f", savedBudget));
    }

    // Update the budget status using current-month expenses
    updateBudgetStatus(budget, monthlyTotal);

      }
private void updateBudgetStatus(double budget, double total) {

    double remaining = budget - total;

    // Update the budget labels
    lblRemainingBudget.setText(
        String.format("₱%,.2f", remaining)
    );

    lblBudgetUsed.setText(
        String.format("₱%,.2f", total)
    );

    int remainingPercent = 0;

    if (budget > 0) {
        remainingPercent = (int) Math.round(
            (remaining / budget) * 100
        );
    }
    

    lblBudgetRemainingPercent.setText(
        remainingPercent + "% remaining"
    );

    // Update the remaining-budget progress bar
    progressBudgetRemaining.setMinimum(0);
    progressBudgetRemaining.setMaximum(100);
    progressBudgetRemaining.setValue(
        Math.max(0, Math.min(100, remainingPercent))
    );

    // Decide which warning should appear
   
    // Decide when the warning should appear
    if (budget <= 0) {
        pnlBudgetWarning.setVisible(false);
    } else if (remaining <= budget * 0.50) {
        pnlBudgetWarning.setVisible(true);
    } else {
        pnlBudgetWarning.setVisible(false);
    }


    if (remainingPercent <= 10) {
        progressBudgetRemaining.setForeground(
                new java.awt.Color(220, 53, 69));
    } else if (remainingPercent <= 30) {
        progressBudgetRemaining.setForeground(
                new java.awt.Color(230, 162, 60));
    } else {
        progressBudgetRemaining.setForeground(
                new java.awt.Color(40, 167, 69));
    }
} 
      
    /**
     * Creates new form Dashboard
     */
    
public Dashboard() {
    initComponents();

    // Hide the budget warning initially
    pnlBudgetWarning.setVisible(false);

    // Set today's date
    DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("MMMM dd, yyyy");

    lblTodayDate.setText(
            LocalDate.now().format(formatter)
    );

    // Maximize the dashboard window
    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

    // Refresh dashboard whenever the window becomes active
    addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowActivated(
                java.awt.event.WindowEvent e) {
            refreshDashboard();
        }
    });

    // Load dashboard data when it opens
    refreshDashboard();
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMain = new javax.swing.JPanel();
        pnlSidebar = new javax.swing.JPanel();
        lblAppName = new javax.swing.JLabel();
        lblSubtitle = new javax.swing.JLabel();
        btnDashboard = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        btnViewExpenses = new javax.swing.JButton();
        btnAddExpense = new javax.swing.JButton();
        lblClockIcon = new javax.swing.JLabel();
        lblAppLogo1 = new javax.swing.JLabel();
        lblTodayDate = new javax.swing.JLabel();
        lblToday = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        pnlRecentExpenses = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblRecentExpenses = new javax.swing.JTable();
        lblRecentTitle = new javax.swing.JLabel();
        lblViewAllExpenses = new javax.swing.JLabel();
        pnlExpensesByCategory = new javax.swing.JPanel();
        lblExpensesByCategoryTitle = new javax.swing.JLabel();
        barTransportation = new javax.swing.JProgressBar();
        barEducation = new javax.swing.JProgressBar();
        barBills = new javax.swing.JProgressBar();
        lblFood = new javax.swing.JLabel();
        lblTransportation = new javax.swing.JLabel();
        lblEducation = new javax.swing.JLabel();
        lblBills = new javax.swing.JLabel();
        barOthers = new javax.swing.JProgressBar();
        lblOthers = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        pnlTotalExpenses = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        lblTotalTitle = new javax.swing.JLabel();
        lblTotalValue = new javax.swing.JLabel();
        pnlTransactions = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        tblTransactionsTitle = new javax.swing.JLabel();
        tblTransactionsValue = new javax.swing.JLabel();
        pnlHighestExpense2 = new javax.swing.JPanel();
        lblHighestTitle2 = new javax.swing.JLabel();
        lblHighestValue2 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        pnlLatestTransaction = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        lblLatestTitle = new javax.swing.JLabel();
        lblLatestDate = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        pnlSetBuget = new javax.swing.JPanel();
        lblSetBudgetTitle = new javax.swing.JLabel();
        tblAmountBudgetInstruction = new javax.swing.JLabel();
        btnSetBudget = new javax.swing.JButton();
        pnlSetBudget = new javax.swing.JPanel();
        lblBudget = new javax.swing.JLabel();
        txtBudget = new javax.swing.JTextField();
        pnlBudgetStatus = new javax.swing.JPanel();
        lblBudgetStatusTitle = new javax.swing.JLabel();
        lblRemainingBudgetTitle = new javax.swing.JLabel();
        lblBudgetUsedTitle = new javax.swing.JLabel();
        lblRemainingBudget = new javax.swing.JTextField();
        progressBudgetRemaining = new javax.swing.JProgressBar();
        lblBudgetRemainingPercent = new javax.swing.JLabel();
        pnlBudgetWarning = new javax.swing.JPanel();
        lblBudgetWarningTitle = new javax.swing.JLabel();
        lblWarningIcon = new javax.swing.JLabel();
        lblBudgetWarningMessage = new javax.swing.JLabel();
        lblBudgetUsedIcon = new javax.swing.JLabel();
        lblBudgetUsed = new javax.swing.JTextField();
        lblRemainingBudgetIcon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlMain.setBackground(new java.awt.Color(255, 255, 255));

        pnlSidebar.setBackground(new java.awt.Color(0, 0, 51));

        lblAppName.setFont(new java.awt.Font("Segoe UI", 1, 19)); // NOI18N
        lblAppName.setForeground(new java.awt.Color(255, 255, 255));
        lblAppName.setText("Expense Tracker");

        lblSubtitle.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        lblSubtitle.setForeground(new java.awt.Color(255, 255, 255));
        lblSubtitle.setText("Manage your daily expenses");

        btnDashboard.setBackground(new java.awt.Color(0, 0, 51));
        btnDashboard.setFont(new java.awt.Font("Segoe UI Symbol", 1, 14)); // NOI18N
        btnDashboard.setForeground(new java.awt.Color(255, 255, 255));
        btnDashboard.setText("🏠︎  Dashboard");
        btnDashboard.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnDashboard.addActionListener(this::btnDashboardActionPerformed);

        btnLogout.setBackground(new java.awt.Color(0, 0, 51));
        btnLogout.setFont(new java.awt.Font("Segoe UI Symbol", 1, 14)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(255, 255, 255));
        btnLogout.setText("➜] Logout");
        btnLogout.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnLogout.addActionListener(this::btnLogoutActionPerformed);

        btnViewExpenses.setBackground(new java.awt.Color(0, 0, 51));
        btnViewExpenses.setFont(new java.awt.Font("Segoe UI Symbol", 1, 14)); // NOI18N
        btnViewExpenses.setForeground(new java.awt.Color(255, 255, 255));
        btnViewExpenses.setText("📊 View Expenses");
        btnViewExpenses.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnViewExpenses.addActionListener(this::btnViewExpensesActionPerformed);

        btnAddExpense.setBackground(new java.awt.Color(0, 0, 51));
        btnAddExpense.setFont(new java.awt.Font("Segoe UI Symbol", 1, 14)); // NOI18N
        btnAddExpense.setForeground(new java.awt.Color(255, 255, 255));
        btnAddExpense.setText("+ Add Expense");
        btnAddExpense.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAddExpense.addActionListener(this::btnAddExpenseActionPerformed);

        lblClockIcon.setFont(new java.awt.Font("Segoe UI Symbol", 1, 42)); // NOI18N
        lblClockIcon.setForeground(new java.awt.Color(255, 255, 255));
        lblClockIcon.setText("🕓");

        lblAppLogo1.setFont(new java.awt.Font("Segoe UI Symbol", 1, 60)); // NOI18N
        lblAppLogo1.setForeground(new java.awt.Color(255, 255, 255));
        lblAppLogo1.setText("💰 ");

        lblTodayDate.setForeground(new java.awt.Color(255, 255, 255));
        lblTodayDate.setText(" October 10, 2026");
        lblTodayDate.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblToday.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblToday.setForeground(new java.awt.Color(255, 255, 255));
        lblToday.setText("Today is ");

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Ang nagmamataas ay ibababa");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("at ang nagpapakumbaba ay itataas.");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Mateo 23:12  ");

        javax.swing.GroupLayout pnlSidebarLayout = new javax.swing.GroupLayout(pnlSidebar);
        pnlSidebar.setLayout(pnlSidebarLayout);
        pnlSidebarLayout.setHorizontalGroup(
            pnlSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(lblTodayDate, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlSidebarLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblAppLogo1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlSidebarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlSidebarLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAddExpense, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnViewExpenses, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15))
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGroup(pnlSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlSidebarLayout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(pnlSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblSubtitle)
                            .addComponent(lblAppName)))
                    .addGroup(pnlSidebarLayout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(lblToday))
                    .addGroup(pnlSidebarLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(jLabel5))
                    .addGroup(pnlSidebarLayout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(lblClockIcon)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlSidebarLayout.setVerticalGroup(
            pnlSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(lblAppLogo1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblAppName, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSubtitle)
                .addGap(53, 53, 53)
                .addComponent(btnDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(btnAddExpense, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(btnViewExpenses, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(lblClockIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(lblToday)
                .addGap(12, 12, 12)
                .addComponent(lblTodayDate)
                .addGap(20, 20, 20))
        );

        pnlRecentExpenses.setBackground(new java.awt.Color(255, 255, 255));
        pnlRecentExpenses.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tblRecentExpenses.setAutoCreateRowSorter(true);
        tblRecentExpenses.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Description", " Category", "Amount", "Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tblRecentExpenses.setGridColor(new java.awt.Color(153, 153, 153));
        tblRecentExpenses.setIntercellSpacing(new java.awt.Dimension(1, 1));
        tblRecentExpenses.setShowHorizontalLines(true);
        tblRecentExpenses.setShowVerticalLines(true);
        jScrollPane1.setViewportView(tblRecentExpenses);

        lblRecentTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblRecentTitle.setText("Recent Expenses");

        lblViewAllExpenses.setBackground(new java.awt.Color(51, 102, 255));
        lblViewAllExpenses.setForeground(new java.awt.Color(51, 51, 255));
        lblViewAllExpenses.setText("View all ->");

        javax.swing.GroupLayout pnlRecentExpensesLayout = new javax.swing.GroupLayout(pnlRecentExpenses);
        pnlRecentExpenses.setLayout(pnlRecentExpensesLayout);
        pnlRecentExpensesLayout.setHorizontalGroup(
            pnlRecentExpensesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRecentExpensesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlRecentExpensesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlRecentExpensesLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pnlRecentExpensesLayout.createSequentialGroup()
                        .addComponent(lblRecentTitle)
                        .addGap(297, 297, 297)
                        .addComponent(lblViewAllExpenses, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pnlRecentExpensesLayout.setVerticalGroup(
            pnlRecentExpensesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRecentExpensesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlRecentExpensesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRecentTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblViewAllExpenses))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        pnlExpensesByCategory.setBackground(new java.awt.Color(255, 255, 255));
        pnlExpensesByCategory.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnlExpensesByCategory.setForeground(new java.awt.Color(255, 255, 255));

        lblExpensesByCategoryTitle.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblExpensesByCategoryTitle.setText("Expenses by Category");

        barTransportation.setBackground(new java.awt.Color(153, 255, 153));

        barEducation.setBackground(new java.awt.Color(255, 153, 51));

        barBills.setBackground(new java.awt.Color(255, 0, 255));

        lblFood.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblFood.setText("Food");

        lblTransportation.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTransportation.setText("Transportation");

        lblEducation.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblEducation.setText("Education");

        lblBills.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBills.setText("Bills");

        barOthers.setBackground(new java.awt.Color(51, 51, 255));

        lblOthers.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblOthers.setText("Others");

        jProgressBar1.setBackground(new java.awt.Color(255, 51, 51));

        javax.swing.GroupLayout pnlExpensesByCategoryLayout = new javax.swing.GroupLayout(pnlExpensesByCategory);
        pnlExpensesByCategory.setLayout(pnlExpensesByCategoryLayout);
        pnlExpensesByCategoryLayout.setHorizontalGroup(
            pnlExpensesByCategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlExpensesByCategoryLayout.createSequentialGroup()
                .addGroup(pnlExpensesByCategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlExpensesByCategoryLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblExpensesByCategoryTitle))
                    .addGroup(pnlExpensesByCategoryLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(pnlExpensesByCategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(barBills, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
                            .addComponent(lblTransportation)
                            .addComponent(lblEducation)
                            .addComponent(lblBills)
                            .addComponent(barOthers, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblOthers)
                            .addComponent(lblFood)
                            .addComponent(barTransportation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(barEducation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jProgressBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlExpensesByCategoryLayout.setVerticalGroup(
            pnlExpensesByCategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlExpensesByCategoryLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblExpensesByCategoryTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblFood)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(lblTransportation)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(barTransportation, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(lblEducation)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(barEducation, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblBills)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(barBills, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblOthers)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(barOthers, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        pnlTotalExpenses.setBackground(new java.awt.Color(204, 204, 255));
        pnlTotalExpenses.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel9.setFont(new java.awt.Font("Segoe UI Symbol", 1, 40)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(102, 204, 255));
        jLabel9.setText("💶");

        lblTotalTitle.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTotalTitle.setForeground(new java.awt.Color(0, 51, 102));
        lblTotalTitle.setText("Total Expenses");

        lblTotalValue.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTotalValue.setForeground(new java.awt.Color(0, 51, 102));
        lblTotalValue.setText("₱0.00");

        javax.swing.GroupLayout pnlTotalExpensesLayout = new javax.swing.GroupLayout(pnlTotalExpenses);
        pnlTotalExpenses.setLayout(pnlTotalExpensesLayout);
        pnlTotalExpensesLayout.setHorizontalGroup(
            pnlTotalExpensesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTotalExpensesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTotalExpensesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTotalTitle)
                    .addComponent(lblTotalValue, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(84, Short.MAX_VALUE))
        );
        pnlTotalExpensesLayout.setVerticalGroup(
            pnlTotalExpensesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTotalExpensesLayout.createSequentialGroup()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTotalTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTotalValue))
        );

        pnlTransactions.setBackground(new java.awt.Color(204, 255, 204));
        pnlTransactions.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel10.setFont(new java.awt.Font("Segoe UI Symbol", 1, 40)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 204, 51));
        jLabel10.setText("📝");

        tblTransactionsTitle.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tblTransactionsTitle.setForeground(new java.awt.Color(0, 204, 51));
        tblTransactionsTitle.setText("Transactions");

        tblTransactionsValue.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        tblTransactionsValue.setForeground(new java.awt.Color(0, 51, 102));
        tblTransactionsValue.setText("₱0.00");

        javax.swing.GroupLayout pnlTransactionsLayout = new javax.swing.GroupLayout(pnlTransactions);
        pnlTransactions.setLayout(pnlTransactionsLayout);
        pnlTransactionsLayout.setHorizontalGroup(
            pnlTransactionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTransactionsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTransactionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tblTransactionsTitle)
                    .addComponent(tblTransactionsValue, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(93, Short.MAX_VALUE))
        );
        pnlTransactionsLayout.setVerticalGroup(
            pnlTransactionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTransactionsLayout.createSequentialGroup()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tblTransactionsTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tblTransactionsValue)
                .addContainerGap())
        );

        pnlHighestExpense2.setBackground(new java.awt.Color(255, 204, 204));
        pnlHighestExpense2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblHighestTitle2.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        lblHighestTitle2.setForeground(new java.awt.Color(255, 51, 51));
        lblHighestTitle2.setText("Highest Expense");

        lblHighestValue2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblHighestValue2.setForeground(new java.awt.Color(0, 51, 102));
        lblHighestValue2.setText("₱0.00");

        jLabel14.setFont(new java.awt.Font("Segoe UI Symbol", 1, 40)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 102, 51));
        jLabel14.setText("🐖");

        javax.swing.GroupLayout pnlHighestExpense2Layout = new javax.swing.GroupLayout(pnlHighestExpense2);
        pnlHighestExpense2.setLayout(pnlHighestExpense2Layout);
        pnlHighestExpense2Layout.setHorizontalGroup(
            pnlHighestExpense2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHighestExpense2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlHighestExpense2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblHighestTitle2)
                    .addComponent(lblHighestValue2, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(84, Short.MAX_VALUE))
            .addGroup(pnlHighestExpense2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlHighestExpense2Layout.createSequentialGroup()
                    .addGap(16, 16, 16)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(112, Short.MAX_VALUE)))
        );
        pnlHighestExpense2Layout.setVerticalGroup(
            pnlHighestExpense2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHighestExpense2Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(lblHighestTitle2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblHighestValue2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pnlHighestExpense2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlHighestExpense2Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(39, Short.MAX_VALUE)))
        );

        pnlLatestTransaction.setBackground(new java.awt.Color(255, 204, 255));
        pnlLatestTransaction.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("Segoe UI Symbol", 1, 40)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("🗓️");

        lblLatestTitle.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblLatestTitle.setForeground(new java.awt.Color(153, 0, 153));
        lblLatestTitle.setText("Latest Transaction");

        lblLatestDate.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblLatestDate.setForeground(new java.awt.Color(0, 51, 102));
        lblLatestDate.setText("April 25, 2026");

        javax.swing.GroupLayout pnlLatestTransactionLayout = new javax.swing.GroupLayout(pnlLatestTransaction);
        pnlLatestTransaction.setLayout(pnlLatestTransactionLayout);
        pnlLatestTransactionLayout.setHorizontalGroup(
            pnlLatestTransactionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLatestTransactionLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblLatestDate, javax.swing.GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(pnlLatestTransactionLayout.createSequentialGroup()
                .addGroup(pnlLatestTransactionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(lblLatestTitle))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlLatestTransactionLayout.setVerticalGroup(
            pnlLatestTransactionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLatestTransactionLayout.createSequentialGroup()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLatestTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblLatestDate)
                .addGap(14, 14, 14))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 51, 102));
        jLabel2.setText("Dashboard");

        jLabel3.setForeground(new java.awt.Color(0, 51, 102));
        jLabel3.setText("Here's a quick overview of your expenses.");

        pnlSetBuget.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblSetBudgetTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblSetBudgetTitle.setForeground(new java.awt.Color(0, 51, 102));
        lblSetBudgetTitle.setText("Set Monthly Budget");

        tblAmountBudgetInstruction.setForeground(new java.awt.Color(0, 51, 102));
        tblAmountBudgetInstruction.setText("Enter the amount you want to budget for this month.");

        btnSetBudget.setBackground(new java.awt.Color(0, 51, 102));
        btnSetBudget.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnSetBudget.setForeground(new java.awt.Color(255, 255, 255));
        btnSetBudget.setText("Set Budget");
        btnSetBudget.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSetBudget.addActionListener(this::btnSetBudgetActionPerformed);

        pnlSetBudget.setBackground(new java.awt.Color(255, 255, 255));
        pnlSetBudget.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblBudget.setForeground(new java.awt.Color(102, 102, 102));
        lblBudget.setText("Monthly Budget (₱)");

        txtBudget.setFont(new java.awt.Font("Segoe UI", 0, 22)); // NOI18N
        txtBudget.setText("          0");
        txtBudget.setBorder(null);
        txtBudget.addActionListener(this::txtBudgetActionPerformed);

        javax.swing.GroupLayout pnlSetBudgetLayout = new javax.swing.GroupLayout(pnlSetBudget);
        pnlSetBudget.setLayout(pnlSetBudgetLayout);
        pnlSetBudgetLayout.setHorizontalGroup(
            pnlSetBudgetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSetBudgetLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlSetBudgetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlSetBudgetLayout.createSequentialGroup()
                        .addComponent(lblBudget)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(txtBudget))
                .addContainerGap())
        );
        pnlSetBudgetLayout.setVerticalGroup(
            pnlSetBudgetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSetBudgetLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblBudget)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtBudget, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );

        javax.swing.GroupLayout pnlSetBugetLayout = new javax.swing.GroupLayout(pnlSetBuget);
        pnlSetBuget.setLayout(pnlSetBugetLayout);
        pnlSetBugetLayout.setHorizontalGroup(
            pnlSetBugetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSetBugetLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlSetBugetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlSetBugetLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(pnlSetBudget, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(btnSetBudget, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(62, 62, 62))
                    .addGroup(pnlSetBugetLayout.createSequentialGroup()
                        .addGroup(pnlSetBugetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblSetBudgetTitle)
                            .addComponent(tblAmountBudgetInstruction))
                        .addContainerGap(118, Short.MAX_VALUE))))
        );
        pnlSetBugetLayout.setVerticalGroup(
            pnlSetBugetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlSetBugetLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblSetBudgetTitle)
                .addGroup(pnlSetBugetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlSetBugetLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(tblAmountBudgetInstruction)
                        .addGap(9, 9, 9)
                        .addComponent(pnlSetBudget, javax.swing.GroupLayout.PREFERRED_SIZE, 63, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlSetBugetLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSetBudget, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))))
        );

        pnlBudgetStatus.setBackground(new java.awt.Color(255, 255, 255));
        pnlBudgetStatus.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblBudgetStatusTitle.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblBudgetStatusTitle.setForeground(new java.awt.Color(0, 51, 102));
        lblBudgetStatusTitle.setText("Budget Status");

        lblRemainingBudgetTitle.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblRemainingBudgetTitle.setText("Remaining Budget");

        lblBudgetUsedTitle.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBudgetUsedTitle.setText("Budget Used");

        lblRemainingBudget.setFont(new java.awt.Font("Segoe UI", 0, 22)); // NOI18N
        lblRemainingBudget.setText("10,000");
        lblRemainingBudget.setBorder(null);
        lblRemainingBudget.addActionListener(this::lblRemainingBudgetActionPerformed);

        progressBudgetRemaining.setBackground(new java.awt.Color(255, 153, 153));
        progressBudgetRemaining.setForeground(new java.awt.Color(255, 153, 153));
        progressBudgetRemaining.setValue(50);

        lblBudgetRemainingPercent.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBudgetRemainingPercent.setText("30% Remaining");

        pnlBudgetWarning.setBackground(new java.awt.Color(255, 255, 51));

        lblBudgetWarningTitle.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBudgetWarningTitle.setText("WARNING!!! Your  buget is getting low!");

        lblWarningIcon.setFont(new java.awt.Font("Segoe UI Symbol", 1, 40)); // NOI18N
        lblWarningIcon.setForeground(new java.awt.Color(255, 102, 51));
        lblWarningIcon.setText("⚠️");

        lblBudgetWarningMessage.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBudgetWarningMessage.setText("You have spent below  50% of your monthly budget.  Consider limiting unncessary expenses.");

        javax.swing.GroupLayout pnlBudgetWarningLayout = new javax.swing.GroupLayout(pnlBudgetWarning);
        pnlBudgetWarning.setLayout(pnlBudgetWarningLayout);
        pnlBudgetWarningLayout.setHorizontalGroup(
            pnlBudgetWarningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBudgetWarningLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblWarningIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlBudgetWarningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblBudgetWarningTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblBudgetWarningMessage))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlBudgetWarningLayout.setVerticalGroup(
            pnlBudgetWarningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBudgetWarningLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlBudgetWarningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBudgetWarningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblWarningIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblBudgetWarningMessage))
                    .addComponent(lblBudgetWarningTitle))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        lblBudgetUsedIcon.setBackground(new java.awt.Color(0, 0, 102));
        lblBudgetUsedIcon.setFont(new java.awt.Font("Segoe UI Symbol", 1, 40)); // NOI18N
        lblBudgetUsedIcon.setForeground(new java.awt.Color(0, 0, 102));
        lblBudgetUsedIcon.setText("◔");

        lblBudgetUsed.setFont(new java.awt.Font("Segoe UI", 0, 22)); // NOI18N
        lblBudgetUsed.setText("10,000");
        lblBudgetUsed.setBorder(null);
        lblBudgetUsed.addActionListener(this::lblBudgetUsedActionPerformed);

        lblRemainingBudgetIcon.setFont(new java.awt.Font("Segoe UI Symbol", 1, 40)); // NOI18N
        lblRemainingBudgetIcon.setForeground(new java.awt.Color(0, 0, 102));
        lblRemainingBudgetIcon.setText("🗂️");

        javax.swing.GroupLayout pnlBudgetStatusLayout = new javax.swing.GroupLayout(pnlBudgetStatus);
        pnlBudgetStatus.setLayout(pnlBudgetStatusLayout);
        pnlBudgetStatusLayout.setHorizontalGroup(
            pnlBudgetStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBudgetStatusLayout.createSequentialGroup()
                .addGap(107, 107, 107)
                .addGroup(pnlBudgetStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblRemainingBudgetTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblRemainingBudget, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addComponent(lblBudgetUsedIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlBudgetStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblBudgetUsed, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblBudgetUsedTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(90, 90, 90)
                .addGroup(pnlBudgetStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBudgetStatusLayout.createSequentialGroup()
                        .addComponent(lblBudgetRemainingPercent, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlBudgetStatusLayout.createSequentialGroup()
                        .addComponent(progressBudgetRemaining, javax.swing.GroupLayout.DEFAULT_SIZE, 443, Short.MAX_VALUE)
                        .addGap(71, 71, 71))))
            .addGroup(pnlBudgetStatusLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblBudgetStatusTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlBudgetStatusLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlBudgetWarning, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(71, 71, 71))
            .addGroup(pnlBudgetStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlBudgetStatusLayout.createSequentialGroup()
                    .addGap(54, 54, 54)
                    .addComponent(lblRemainingBudgetIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(933, Short.MAX_VALUE)))
        );
        pnlBudgetStatusLayout.setVerticalGroup(
            pnlBudgetStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBudgetStatusLayout.createSequentialGroup()
                .addComponent(lblBudgetStatusTitle)
                .addGroup(pnlBudgetStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBudgetStatusLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(pnlBudgetStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlBudgetStatusLayout.createSequentialGroup()
                                .addGroup(pnlBudgetStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblBudgetUsedTitle)
                                    .addComponent(lblRemainingBudgetTitle))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(pnlBudgetStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblRemainingBudget, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblBudgetUsed, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(lblBudgetUsedIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlBudgetStatusLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(lblBudgetRemainingPercent)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(progressBudgetRemaining, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(16, 16, 16)
                .addComponent(pnlBudgetWarning, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(pnlBudgetStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlBudgetStatusLayout.createSequentialGroup()
                    .addGap(33, 33, 33)
                    .addComponent(lblRemainingBudgetIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(84, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout pnlMainLayout = new javax.swing.GroupLayout(pnlMain);
        pnlMain.setLayout(pnlMainLayout);
        pnlMainLayout.setHorizontalGroup(
            pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMainLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlSidebar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlMainLayout.createSequentialGroup()
                        .addGroup(pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(pnlSetBuget, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(121, 121, 121)
                        .addGroup(pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(pnlTotalExpenses, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pnlHighestExpense2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31)
                        .addGroup(pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pnlLatestTransaction, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pnlTransactions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlMainLayout.createSequentialGroup()
                        .addComponent(pnlRecentExpenses, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlExpensesByCategory, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(pnlBudgetStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        pnlMainLayout.setVerticalGroup(
            pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMainLayout.createSequentialGroup()
                .addGroup(pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pnlSidebar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pnlMainLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(pnlMainLayout.createSequentialGroup()
                                .addComponent(pnlTransactions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(pnlLatestTransaction, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlMainLayout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(pnlSetBuget, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlMainLayout.createSequentialGroup()
                                .addComponent(pnlTotalExpenses, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(pnlHighestExpense2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pnlBudgetStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pnlRecentExpenses, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pnlExpensesByCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlMain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlMain, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDashboardActionPerformed
     JOptionPane.showMessageDialog(this, "You are already on the Dashboard.");
    }//GEN-LAST:event_btnDashboardActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        // TODO add your handling code here:
        int choice = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to log out?",
        "Logout",
        JOptionPane.YES_NO_OPTION
    );

    if (choice == JOptionPane.YES_OPTION) {
        new Login().setVisible(true);
        this.dispose();
    }
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnViewExpensesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewExpensesActionPerformed
  
 ViewExpenses viewForm = new ViewExpenses();
    viewForm.setLocationRelativeTo(null);
    viewForm.setVisible(true);
    }//GEN-LAST:event_btnViewExpensesActionPerformed

    private void btnAddExpenseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddExpenseActionPerformed

     
try {
    AddExpenses form = new AddExpenses();
    form.setLocationRelativeTo(this);
    form.setVisible(true);

} catch (Exception e) {
    JOptionPane.showMessageDialog(this,
            "Unable to open Add Expenses:\n" + e.getMessage(),
            "Form Error",
            JOptionPane.ERROR_MESSAGE);
}

    }//GEN-LAST:event_btnAddExpenseActionPerformed

    private void btnSetBudgetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSetBudgetActionPerformed
        // TODO add your handling code here:
 
    try {
        String input = txtBudget.getText()
                .trim()
                .replace(",", "");

        double budget = Double.parseDouble(input);

        if (!Double.isFinite(budget) || budget <= 0) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid budget greater than zero."
            );
            return;
        }

        // Update both budget variables
        monthlyBudget = budget;
        ExpenseService.getInstance().setMonthlyBudget(budget);

        refreshDashboard();

        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Monthly budget updated successfully!"
        );

    } catch (NumberFormatException e) {
        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Please enter a valid amount, such as 10000."
        );
    }
  
    }//GEN-LAST:event_btnSetBudgetActionPerformed

    private void txtBudgetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBudgetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBudgetActionPerformed

    private void lblRemainingBudgetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblRemainingBudgetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lblRemainingBudgetActionPerformed

    private void lblBudgetUsedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblBudgetUsedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lblBudgetUsedActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Dashboard().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar barBills;
    private javax.swing.JProgressBar barEducation;
    private javax.swing.JProgressBar barOthers;
    private javax.swing.JProgressBar barTransportation;
    private javax.swing.JButton btnAddExpense;
    private javax.swing.JButton btnDashboard;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnSetBudget;
    private javax.swing.JButton btnViewExpenses;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblAppLogo1;
    private javax.swing.JLabel lblAppName;
    private javax.swing.JLabel lblBills;
    private javax.swing.JLabel lblBudget;
    private javax.swing.JLabel lblBudgetRemainingPercent;
    private javax.swing.JLabel lblBudgetStatusTitle;
    private javax.swing.JTextField lblBudgetUsed;
    private javax.swing.JLabel lblBudgetUsedIcon;
    private javax.swing.JLabel lblBudgetUsedTitle;
    private javax.swing.JLabel lblBudgetWarningMessage;
    private javax.swing.JLabel lblBudgetWarningTitle;
    private javax.swing.JLabel lblClockIcon;
    private javax.swing.JLabel lblEducation;
    private javax.swing.JLabel lblExpensesByCategoryTitle;
    private javax.swing.JLabel lblFood;
    private javax.swing.JLabel lblHighestTitle2;
    private javax.swing.JLabel lblHighestValue2;
    private javax.swing.JLabel lblLatestDate;
    private javax.swing.JLabel lblLatestTitle;
    private javax.swing.JLabel lblOthers;
    private javax.swing.JLabel lblRecentTitle;
    private javax.swing.JTextField lblRemainingBudget;
    private javax.swing.JLabel lblRemainingBudgetIcon;
    private javax.swing.JLabel lblRemainingBudgetTitle;
    private javax.swing.JLabel lblSetBudgetTitle;
    private javax.swing.JLabel lblSubtitle;
    private javax.swing.JLabel lblToday;
    private javax.swing.JLabel lblTodayDate;
    private javax.swing.JLabel lblTotalTitle;
    private javax.swing.JLabel lblTotalValue;
    private javax.swing.JLabel lblTransportation;
    private javax.swing.JLabel lblViewAllExpenses;
    private javax.swing.JLabel lblWarningIcon;
    private javax.swing.JPanel pnlBudgetStatus;
    private javax.swing.JPanel pnlBudgetWarning;
    private javax.swing.JPanel pnlExpensesByCategory;
    private javax.swing.JPanel pnlHighestExpense2;
    private javax.swing.JPanel pnlLatestTransaction;
    private javax.swing.JPanel pnlMain;
    private javax.swing.JPanel pnlRecentExpenses;
    private javax.swing.JPanel pnlSetBudget;
    private javax.swing.JPanel pnlSetBuget;
    private javax.swing.JPanel pnlSidebar;
    private javax.swing.JPanel pnlTotalExpenses;
    private javax.swing.JPanel pnlTransactions;
    private javax.swing.JProgressBar progressBudgetRemaining;
    private javax.swing.JLabel tblAmountBudgetInstruction;
    private javax.swing.JTable tblRecentExpenses;
    private javax.swing.JLabel tblTransactionsTitle;
    private javax.swing.JLabel tblTransactionsValue;
    private javax.swing.JTextField txtBudget;
    // End of variables declaration//GEN-END:variables
}

